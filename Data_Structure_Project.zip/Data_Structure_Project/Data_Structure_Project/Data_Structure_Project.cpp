#include <iostream>
#include <vector>
#include <string>
#include <unordered_map>
#include <algorithm>

using namespace std;

// Define Course class to represent a course
class Course {
public:
    string name; // Course name
    string code; // Course code
    int maxStudents; // Maximum number of students
    vector<string> prerequisites; // List of prerequisite courses
    int hours; // Number of hours

    Course() : name(""), code(""), maxStudents(0), prerequisites(), hours(0) {}

    // Constructor for the Course class
    Course(string name, string code, int maxStudents, vector<string> prerequisites, int hours)
        : name(name), code(code), maxStudents(maxStudents), prerequisites(prerequisites), hours(hours) {}
};

// Define Student class to represent a student
class Student {
public:
    string name; // Student's name
    string id; // Student's ID
    string password; // Student's password
    vector<string> finishedCourses; // List of completed courses
    vector<string> inProgressCourses; // List of courses currently being taken
    int academicYear; // Student's academic year

    Student() : name(""), id(""), password(""), finishedCourses(), inProgressCourses(), academicYear(0) {}

    // Constructor for the Student class
    Student(string name, string id, string password, int academicYear)
        : name(name), id(id), password(password), academicYear(academicYear) {}
};

// Define Admin class to represent an administrator
class Admin {
public:
    string name; // Admin's name
    string password; // Admin's password

    // Constructor for the Admin class
    Admin(string name, string password)
        : name(name), password(password) {}
};

// Define System class to manage the entire system
class System {
private:
    unordered_map<string, Course> courses; // Map to store courses using course code as key
    unordered_map<string, Student> students; // Map to store students using student ID as key
    Admin admin; // Admin object to store admin data

public:
    // Constructor for the System class
    System(Admin admin) : admin(admin) {}

    // Student functions
    void studentLogin();
    void viewAvailableCourses();
    void viewCourseDetails(string courseCode);
    void registerCourse(string studentId, string courseCode);
    void viewStudentCourses(string studentId);
    void editStudentData(string studentId);

    // Admin functions
    void adminLogin();
    void addNewStudent(Student student);
    void addNewCourse(Course course);
    void enterCoursePrerequisite(string courseCode, vector<string> prerequisites);
    void viewStudentsInCourse(string courseCode);
    void viewStudentCoursesForAdmin(string studentID);
    void editCourseData(string courseCode);
};

// Student login function
void System::studentLogin() {
    string id, password;
    cout << "Enter Student ID: ";
    cin >> id;
    cout << "Enter Password: ";
    cin >> password;

    // Verify login credentials
    if (students.find(id) != students.end() && students[id].password == password) {
        cout << "Login successful!\n\n";
    }
    else {
        cout << "Invalid ID or Password!\n";
    }
}

// Function to view available courses
void System::viewAvailableCourses() {
    for (const auto& course : courses) {
        cout << "Course Code: " << course.second.code << ", Course Name: " << course.second.name << "\n";
    }
}

// Function to view details of a specific course
void System::viewCourseDetails(string courseCode) {
    if (courses.find(courseCode) != courses.end()) {
        Course course = courses[courseCode];
        cout << "Course Name: " << course.name << "\n"
            << "Course Code: " << course.code << "\n"
            << "Max Students: " << course.maxStudents << "\n"
            << "Hours: " << course.hours << "\n"
            << "Prerequisites: ";
        for (const auto& pre : course.prerequisites) {
            cout << pre << " ";
        }
        cout << "\n";
    }
    else {
        cout << "Course not found!\n";
    }
}

// Function to register a student in a course
void System::registerCourse(string studentId, string courseCode) {
    if (students.find(studentId) != students.end() && courses.find(courseCode) != courses.end()) {
        Student& student = students[studentId];
        Course& course = courses[courseCode];

        // Check prerequisites
        bool canRegister = true;
        for (const auto& pre : course.prerequisites) {
            if (find(student.finishedCourses.begin(), student.finishedCourses.end(), pre) == student.finishedCourses.end()) {
                canRegister = false;
                break;
            }
        }

        // Register the student if prerequisites are met and course is not full
        if (canRegister && course.maxStudents > 0) {
            student.inProgressCourses.push_back(courseCode);
            course.maxStudents--;
            cout << "Course registered successfully!\n";
        }
        else {
            cout << "Cannot register for the course. Prerequisites not met or course is full.\n";
        }
    }
    else {
        cout << "Invalid student ID or course code!\n";
    }
}

// Function to view courses of a specific student
void System::viewStudentCourses(string studentId) {
    if (students.find(studentId) != students.end()) {
        Student& student = students[studentId];
        cout << "Finished Courses: ";
        for (const auto& course : student.finishedCourses) {
            cout << course << " ";
        }
        cout << "\nIn Progress Courses: ";
        for (const auto& course : student.inProgressCourses) {
            cout << course << " ";
        }
        cout << "\n";
    }
    else {
        cout << "Student not found!\n";
    }
}

// Function to edit student data (not fully implemented)
void System::editStudentData(string studentId) {
    cout << "Edit student data functionality.\n";
}

// Admin login function
void System::adminLogin() {
    string name, password;
    cout << "Enter Admin Name: ";
    cin >> name;
    cout << "Enter Password: ";
    cin >> password;

    // Verify login credentials
    if (admin.name == name && admin.password == password) {
        cout << "Admin login successful!\n\n";
    }
    else {
        cout << "Invalid Name or Password!\n";
    }
}

// Function to add a new student
void System::addNewStudent(Student student) {
    students[student.id] = student;
    //cout << "Student added successfully!\n";
}

// Function to add a new course
void System::addNewCourse(Course course) {
    courses[course.code] = course;
    // cout << "Course added successfully!\n";
}

// Function to enter prerequisites for a course
void System::enterCoursePrerequisite(string courseCode, vector<string> prerequisites) {
    if (courses.find(courseCode) != courses.end()) {
        courses[courseCode].prerequisites = prerequisites;
        cout << "Prerequisites updated successfully!\n";
    }
    else {
        cout << "Course not found!\n";
    }
}

// Function to view students registered in a specific course
void System::viewStudentsInCourse(string courseCode) {
    if (courses.find(courseCode) != courses.end()) {
        cout << "Students in course " << courseCode << ":\n";
        for (const auto& student : students) {
            if (find(student.second.inProgressCourses.begin(), student.second.inProgressCourses.end(), courseCode) != student.second.inProgressCourses.end()) {
                cout << student.second.name << " (" << student.second.id << ")\n";
            }
        }
    }
    else {
        cout << "Course not found!\n";
    }
}

// Function to view courses of a specific student for admin
void System::viewStudentCoursesForAdmin(string studentID) {
    if (students.find(studentID) != students.end()) {
        Student& student = students[studentID];
        cout << "Finished Courses: ";
        for (const auto& course : student.finishedCourses) {
            cout << course << " ";
        }
        cout << "\nIn Progress Courses: ";
        for (const auto& course : student.inProgressCourses) {
            cout << course << " ";
        }
        cout << "\n";
    }
    else {
        cout << "Student not found!\n";
    }
}

// Function to edit course data (not fully implemented)
void System::editCourseData(string courseCode) {
    cout << "Edit course data functionality.\n";
}

//assignPrerequisite
int main() {
    // Initialize admin
    Admin admin("ahmed", "Bla@Bla@Bla");
    System system(admin);

    // Adding courses to the system
    system.addNewCourse(Course("Mathematics I", "MATH101", 40, {}, 3));
    system.addNewCourse(Course("Mathematics II", "MATH102", 40, { "MATH101" }, 3));
    system.addNewCourse(Course("Physics I", "PHYS101", 30, {}, 4));
    system.addNewCourse(Course("Physics II", "PHYS102", 30, { "PHYS101" }, 4));
    system.addNewCourse(Course("Introduction to Programming", "CS101", 50, {}, 3));
    system.addNewCourse(Course("Data Structures", "CS102", 50, { "CS101" }, 3));
    system.addNewCourse(Course("Algorithms", "CS201", 40, { "CS102" }, 3));
    system.addNewCourse(Course("Operating Systems", "CS202", 40, { "CS102" }, 3));
    system.addNewCourse(Course("Computer Networks", "CS301", 30, { "CS102" }, 3));
    system.addNewCourse(Course("Database Systems", "CS302", 35, { "CS102" }, 3));
    system.addNewCourse(Course("Software Engineering", "CS401", 40, { "CS201", "CS202" }, 3));


    // Register some students with different names
    system.addNewStudent(Student("Yousef Abdelsalam", "225146", "GooPassword", 2));
    system.addNewStudent(Student("Hisham Khlifa", "225199", "EtshPassword", 1));

    int choice;
    while (true) {
        cout << "1. Admin Login\n";
        cout << "2. Student Login\n";
        cout << "3. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1) {
            system.adminLogin();
            int adminChoice;
            while (true) {
                cout << "1. Add New Student\n";
                cout << "2. Add New Course\n";
                cout << "3. Enter Course Prerequisite\n";
                cout << "4. View Students in Course\n";
                cout << "5. View Student Courses\n";
                cout << "6. Edit Course Data\n";
                cout << "7. Logout\n";
                cout << "Enter your choice: ";
                cin >> adminChoice;

                if (adminChoice == 1) {
                    string name, id, password;
                    int year;
                    cout << "Enter student name: ";
                    cin >> name;
                    cout << "Enter student ID: ";
                    cin >> id;
                    cout << "Enter password: ";
                    cin >> password;
                    cout << "Enter academic year: ";
                    cin >> year;
                    system.addNewStudent(Student(name, id, password, year));
                }
                else if (adminChoice == 2) {
                    string name, code;
                    int maxStudents, hours;
                    cout << "Enter course name: ";
                    cin >> name;
                    cout << "Enter course code: ";
                    cin >> code;
                    cout << "Enter max students: ";
                    cin >> maxStudents;
                    cout << "Enter hours: ";
                    cin >> hours;
                    vector<string> prerequisites;
                    system.addNewCourse(Course(name, code, maxStudents, prerequisites, hours));
                }
                else if (adminChoice == 3) {
                    string courseCode;
                    int n;
                    cout << "Enter course code: ";
                    cin >> courseCode;
                    cout << "Enter number of prerequisites: ";
                    cin >> n;
                    vector<string> prerequisites(n);
                    cout << "Enter prerequisites: ";
                    for (int i = 0; i < n; ++i) {
                        cin >> prerequisites[i];
                    }
                    system.enterCoursePrerequisite(courseCode, prerequisites);
                }
                else if (adminChoice == 4) {
                    string courseCode;
                    cout << "Enter course code: ";
                    cin >> courseCode;
                    system.viewStudentsInCourse(courseCode);
                }
                else if (adminChoice == 5) {
                    string studentID;
                    cout << "Enter student ID: ";
                    cin >> studentID;
                    system.viewStudentCoursesForAdmin(studentID);
                }
                else if (adminChoice == 6) {
                    string courseCode;
                    cout << "Enter course code: ";
                    cin >> courseCode;
                    system.editCourseData(courseCode);
                }
                else if (adminChoice == 7) {
                    break;
                }
                else {
                    cout << "Invalid choice, please try again.\n";
                }
            }
        }
        else if (choice == 2) {
            system.studentLogin();
            int studentChoice;
            while (true) {
                cout << "1. View Available Courses\n";
                cout << "2. View Course Details\n";
                cout << "3. Register for a Course\n";
                cout << "4. View My Courses\n";
                cout << "5. Edit My Data\n";
                cout << "6. Logout\n";
                cout << "Enter your choice: ";
                cin >> studentChoice;

                if (studentChoice == 1) {
                    system.viewAvailableCourses();
                }
                else if (studentChoice == 2) {
                    string courseCode;
                    cout << "Enter course code: ";
                    cin >> courseCode;
                    system.viewCourseDetails(courseCode);
                }
                else if (studentChoice == 3) {
                    string studentId, courseCode;
                    cout << "Enter your student ID: ";
                    cin >> studentId;
                    cout << "Enter course code: ";
                    cin >> courseCode;
                    system.registerCourse(studentId, courseCode);
                }
                else if (studentChoice == 4) {
                    string studentId;
                    cout << "Enter your student ID: ";
                    cin >> studentId;
                    system.viewStudentCourses(studentId);
                }
                else if (studentChoice == 5) {
                    string studentId;
                    cout << "Enter your student ID: ";
                    cin >> studentId;
                    system.editStudentData(studentId);
                }
                else if (studentChoice == 6) {
                    break;
                }
                else {
                    cout << "Invalid choice, please try again.\n";
                }
            }
        }
        else if (choice == 3) {
            break;
        }
        else {
            cout << "Invalid choice, please try again.\n";
        }
    }

    return 0;
}

